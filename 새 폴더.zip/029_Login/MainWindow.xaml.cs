﻿using System.Windows;

namespace _029_Login
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (txtID.Text == "abcd" && txtPW.Password == "1234")
                MessageBox.Show("로그인 성공!");
            else
                MessageBox.Show("로그인 실패!");
        }
    }
}
