﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace _025_SensorMonitoring
{
    public partial class Form1 : Form
    {
        SerialPort sPort = null;
        private double xCount = 50;
        //List<SensorData> myData = new List<SensorData>();
        
        // 시뮬레이션 용
        Timer t = new Timer();
        Random r = new Random();
        public Form1()
        {
            InitializeComponent();

            foreach(var ports in SerialPort.GetPortNames()) // ComboBox
                comboBox1.Items.Add(ports);
            comboBox1.Text = "Select Port";

            // 아두이노의 A0에서 받는 값의 범위
            progressBar1.Minimum = 0;   progressBar1.Maximum = 1023;

            ChartSetting(); // 차트 모양 세팅
            InitSetting(); // 초기 세팅
        }

        private void InitSetting()
        {
            btnPortValue.BackColor = Color.Blue;
            btnPortValue.ForeColor = Color.White;
            btnPortValue.Text = "";
            btnPortValue.Font = new Font("맑은 고딕", 12, FontStyle.Bold);

            label1.Text = "Connection Time : ";
            textBox1.TextAlign = HorizontalAlignment.Center;
            btnConnect.Enabled = true;
            btnDisconnect.Enabled = false;
        }
        private void ChartSetting()
        {

            chart1.Titles.Add("조도");
            chart2.Titles.Add("온도/습도");

            chart1.ChartAreas.Clear();
            chart1.ChartAreas.Add("limu");

            chart1.Series.Clear();
            chart1.Series.Add("lumi");
            chart1.ChartAreas[0].AxisX.Minimum = 0;
            chart1.ChartAreas[0].AxisX.Maximum = xCount;
            chart1.ChartAreas[0].AxisX.Interval = xCount / 4;
            chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.Gray;
            chart1.ChartAreas[0].AxisX.MajorGrid.LineDashStyle
              = ChartDashStyle.Dash;

            chart1.ChartAreas[0].AxisY.Minimum = 0;
            chart1.ChartAreas[0].AxisY.Maximum = 800;
            chart1.ChartAreas[0].AxisY.Interval = 200;
            chart1.ChartAreas[0].AxisY.MajorGrid.LineColor = Color.Gray;
            chart1.ChartAreas[0].AxisY.MajorGrid.LineDashStyle
              = ChartDashStyle.Dash;

            chart1.ChartAreas[0].BackColor = Color.Black;

            chart2.Series.Clear();
            chart2.Series.Add("temp");
            chart2.Series.Add("humi");

            chart2.ChartAreas[0].AxisX.Minimum = 0;
            chart2.ChartAreas[0].AxisX.Maximum = xCount;
            chart2.ChartAreas[0].AxisX.Interval = xCount / 4;
            chart2.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.Gray;
            chart2.ChartAreas[0].AxisX.MajorGrid.LineDashStyle
              = ChartDashStyle.Dash;

            chart2.ChartAreas[0].AxisY.Minimum = 0;
            chart2.ChartAreas[0].AxisY.Maximum = 100;
            chart2.ChartAreas[0].AxisY.Interval = 20;
            chart2.ChartAreas[0].AxisY.MajorGrid.LineColor = Color.Gray;
            chart2.ChartAreas[0].AxisY.MajorGrid.LineDashStyle
              = ChartDashStyle.Dash;

            chart2.ChartAreas[0].BackColor = Color.Black;

            // Series 디자인
            chart1.Series[0].ChartType = SeriesChartType.Line;
            chart1.Series[0].Color = Color.LightGreen;
            chart1.Series[0].BorderWidth = 2;

            chart2.Series[0].Color = Color.LightBlue;
            chart2.Series[0].BorderWidth = 2;
            chart2.Series[0].ChartType = SeriesChartType.Line;

            chart2.Series[1].Color = Color.Orange;
            chart2.Series[1].BorderWidth = 2;
            chart2.Series[1].ChartType = SeriesChartType.Line;
        }

        private void 시작ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            t.Interval = 1000;
            t.Tick += T_Tick;
            t.Start();
        }

        private void T_Tick(object sender, EventArgs e)
        {
            int value = r.Next(800); // 조도
            int temp = r.Next(35); // 온도
            int humi = r.Next(30, 90); // 습도

            string s = string.Format("{0}\t{1}\t{2}", temp, humi, value);
            ShowValue(s);
        }

        static int counter = 0;
        static int skip = 0;

        private void ShowValue(string s)
        {
            counter++;
            listBox1.Items.Add(s);
            listBox1.SelectedIndex = listBox1.Items.Count - 1; // 커서가 쫓아감

            if (++skip < 3) // 통신된 데이터 3개를 무시한다
                return;
            else
                skip = 3;

            string[] sub = new string[3];
            sub = s.Split('\t'); // 빈칸을 기준으로 s 분리 -> 3개의 문자열로 나뉘어짐

            int lumi = 0; // 조도
            double temp = 0; // 온도
            double humi = 0; // 습도

            temp = double.Parse(sub[0]);
            humi = double.Parse(sub[1]);
            lumi = int.Parse(sub[2]);


            progressBar1.Value = lumi;
            chart1.Series[0].Points.Add(lumi);
            chart2.Series[0].Points.Add(temp);
            chart2.Series[1].Points.Add(humi);

            // 차트에 스크롤 기능 추가
            chart1.ChartAreas[0].AxisX.Minimum = 0;
            chart1.ChartAreas[0].AxisX.Maximum 
                = (counter >= xCount) ? counter : xCount;

            if(counter > xCount)
            {
                chart1.ChartAreas[0].AxisX.ScaleView.Zoom(counter - xCount, counter);
                chart2.ChartAreas[0].AxisX.ScaleView.Zoom(counter - xCount, counter);
            }
            // Zoom이 뭐야
            
            chart2.ChartAreas[0].AxisX.Minimum = 0;
            chart2.ChartAreas[0].AxisX.Maximum 
                = (counter >= xCount) ? counter : xCount; // ?의 역할
        
        }

        private void 끝ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            t.Stop();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (sPort != null) // sPort가 이미 설정되었다면? return 아니면 에러
                return;

            ComboBox cb = sender as ComboBox; // sender를 cb로 씀 == (ComboBox)sender
            sPort = new SerialPort(cb.SelectedItem.ToString());
            sPort.Open();
            sPort.DataReceived += SPort_DataReceived;

            label1.Text = "Connection Time : " + DateTime.Now.ToString();
            
            btnDisconnect.Enabled = true;
            btnConnect.Enabled = false;
            
            
        }

        private void SPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            string s = sPort.ReadLine();
            this.BeginInvoke((new Action(delegate { ShowValue(s); })));
        }
    }
}
